# Steganography Web Application

This is a simple web application built with Flask that allows users to encode a secret message into an image (steganography) and decode a message from an image.

## Features

*   **Encode**: Hide a text message within a PNG image.
*   **Decode**: Extract a hidden message from a PNG image.
*   Encryption key required for encoding/decoding.
*   Image preview before upload.
*   Download of the encoded image.

## Project Structure

```
├── app.py                # Main Flask application
├── requirements.txt      # Python dependencies
├── static/
│   ├── css/
│   │   └── style.css     # CSS stylesheets
│   └── js/
│       └── main.js       # JavaScript for client-side interactions
├── templates/
│   ├── index.html        # Home page
│   ├── encode.html       # Page for encoding messages
│   └── decode.html       # Page for decoding messages
├── uploads/              # Directory for temporary image uploads (created automatically)
├── .gitignore            # Specifies intentionally untracked files that Git should ignore
├── vercel.json           # Vercel deployment configuration
└── README.md             # This file
```

## Setup and Installation

1.  **Clone the repository:**
    ```bash
    git clone <repository-url>
    cd <repository-name>
    ```

2.  **Create a virtual environment (recommended):**
    ```bash
    python -m venv venv
    source venv/bin/activate  # On Windows: venv\Scripts\activate
    ```

3.  **Install dependencies:**
    ```bash
    pip install -r requirements.txt
    ```

## How to Run

1.  **Ensure you are in the project's root directory and your virtual environment is activated.**

2.  **Run the Flask development server:**
    ```bash
    flask run
    ```
    Or, if you want to run in debug mode (as configured in `app.py`):
    ```bash
    python app.py
    ```

3.  **Open your web browser and go to:**
    ```
    http://127.0.0.1:5000/
    ```

## Usage

*   Navigate to the "Hide Message" page (was "Encode Message") to hide your message in an image.
*   Navigate to the "Reveal Message" page (was "Decode Message") to extract a message from an image.
*   Follow the on-screen instructions. Note that only PNG images are supported for encoding and decoding. An encryption key is required for both operations.

## Dependencies

*   Flask
*   gunicorn
*   opencv-python-headless
*   numpy
*   Pillow

## TODO (Future Enhancements)

The following are potential areas for future improvements and feature additions:

*   **Advanced Error Handling & Logging**:
    *   Implement more specific client-side validation messages (e.g., for key length, message size).
    *   Integrate server-side logging (e.g., to a file or a logging service) for easier debugging and monitoring.
    *   Provide more granular error feedback to the user instead of generic messages for certain failures.

*   **Security Enhancements**:
    *   **Stronger Encryption**: Replace XOR encryption with a more robust algorithm like AES-256. This would require a library like PyCryptodome.
    *   **Key Derivation**: Use a key derivation function (KDF) like PBKDF2 or Argon2 to derive the encryption key from the user's password, adding salt and iterations to protect against brute-force and rainbow table attacks.
    *   **Password Strength Meter**: Provide visual feedback on the strength of the chosen encryption key.
    *   **Metadata Protection**: Consider if any metadata about the hidden message (like its original length if not encrypted) could be further obfuscated.

*   **Steganography Algorithm Improvements**:
    *   **Multi-bit Encoding**: Explore techniques to hide more than 1 bit per pixel color channel (e.g., 2 or 3 LSBs), balancing capacity with image distortion.
    *   **Adaptive Steganography**: Implement methods that select pixel locations based on image characteristics to minimize detectability.
    *   **Different File Types**: Extend support to other lossless image formats (e.g., BMP, TIFF) or even lossy formats like JPEG (though LSB is highly problematic with JPEG).
    *   **Data Compression**: Compress the message before encryption and encoding to increase effective capacity.

*   **User Interface & Experience (UI/UX)**:
    *   **Progress Indicators**: For large files or long messages, provide a visual progress bar during encoding/decoding.
    *   **Drag and Drop Uploads**: Allow users to drag and drop image files.
    *   **Batch Processing**: Allow encoding/decoding of multiple images/messages at once.
    *   **Internationalization (i18n)**: Support multiple languages for the UI.
    *   **Accessibility (a11y)**: Ensure the application is accessible to users with disabilities (e.g., proper ARIA attributes, keyboard navigation).

*   **Testing & Development**:
    *   **Comprehensive Unit Tests**: Write unit tests for backend logic (encryption, encoding, decoding functions).
    *   **Integration Tests**: Test the interaction between frontend and backend components.
    *   **End-to-End Tests**: Automate UI testing using tools like Selenium or Playwright.
    *   **CI/CD Pipeline**: Set up a Continuous Integration/Continuous Deployment pipeline for automated testing and deployment.

*   **Additional Features**:
    *   **Message Size Estimation**: Before encoding, estimate if the message will fit in the chosen image.
    *   **Image Quality Check**: Warn users if the uploaded image might be unsuitable (e.g., too small, heavily compressed).
    *   **Steganalysis Tools**: For educational purposes, one might link to or discuss basic steganalysis techniques.

## Deploying to Vercel

This application can be deployed to Vercel.

1.  **Sign up on Vercel**: Create an account at [vercel.com](https://vercel.com/).
2.  **Connect Your Git Repository**:
    *   Push your project to a GitHub, GitLab, or Bitbucket repository.
    *   On your Vercel dashboard, click "New Project".
    *   Import your Git repository.
3.  **Configure Project**:
    *   Vercel should automatically detect it as a Python application due to the `vercel.json` and `requirements.txt`.
    *   **Framework Preset**: Select "Other" (as Flask might not be an explicit preset, or if it is, select Flask).
    *   **Build and Output Settings**:
        *   **Build Command**: `pip install -r requirements.txt` (Vercel often handles this automatically for Python projects, but you can specify if needed). Or, if you have other build steps: `python -m pip install --upgrade pip && pip install -r requirements.txt && # any other build commands`.
        *   **Output Directory**: Vercel typically handles this for Python; leave default unless you have specific needs.
        *   **Install Command**: `pip install -r requirements.txt` is standard.
    *   **Entrypoint**: Your `app.py` (or whatever your main Flask file is named) will be the entry point. `gunicorn app:app` is often used by Vercel for Python apps. The `vercel.json` helps define this.
4.  **Environment Variables (if any)**:
    *   If your application requires environment variables (e.g., secret keys, API tokens), add them in the "Environment Variables" section of your project settings on Vercel. This app currently doesn't require specific environment variables beyond what Flask uses internally.
5.  **Deploy**: Click the "Deploy" button. Vercel will build and deploy your application.
6.  **Access Your App**: Once deployed, Vercel will provide you with a URL to access your live application (e.g., `your-project-name.vercel.app`).

**Note on `gunicorn`**: `gunicorn` has been added to `requirements.txt` as it's a common WSGI server used by Vercel to serve Python web applications. The `vercel.json` configuration tells Vercel how to use `app.py`.
