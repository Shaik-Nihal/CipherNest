document.addEventListener('DOMContentLoaded', function() {

    // --- Helper function to display alerts ---
    function showAlert(alertContainerId, message, type = 'danger') { // type can be 'success' or 'danger'
        const alertContainer = document.getElementById(alertContainerId);
        if (alertContainer) {
            const alertTypeClass = type === 'success' ? 'alert-success' : 'alert-danger';
            alertContainer.innerHTML = `<div class="alert ${alertTypeClass} alert-dismissible fade show" role="alert">
                                            ${message}
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>`;
        }
    }

    // --- Helper function to clear alerts ---
    function clearAlerts(alertContainerId) {
        const alertContainer = document.getElementById(alertContainerId);
        if (alertContainer) {
            alertContainer.innerHTML = '';
        }
    }

    // --- Universal Image Preview Logic ---
    // This function will be called by event listeners on specific pages
    function setupImagePreview(fileInputId, previewElementId) {
        const imageInput = document.getElementById(fileInputId);
        const previewElement = document.getElementById(previewElementId);

        if (imageInput && previewElement) {
            imageInput.addEventListener('change', function(event) {
                const file = event.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        previewElement.src = e.target.result;
                        previewElement.style.display = 'block';
                    }
                    reader.readAsDataURL(file);
                } else {
                    previewElement.src = '#';
                    previewElement.style.display = 'none';
                }
            });
        }
    }

    // --- Encode Page Logic ---
    const encodeForm = document.getElementById('encodeForm');
    if (encodeForm) {
        setupImagePreview('imageFile', 'originalImagePreview'); // Setup preview for original image

        const encodedImagePreview = document.getElementById('encodedImagePreview');
        const downloadLink = document.getElementById('downloadEncodedImage');
        const downloadLinkContainer = document.getElementById('downloadLinkContainer');

        encodeForm.addEventListener('submit', function(event) {
            event.preventDefault();
            clearAlerts('encodeAlerts');
            if(encodedImagePreview) encodedImagePreview.style.display = 'none';
            if(downloadLinkContainer) downloadLinkContainer.style.display = 'none';


            const formData = new FormData(encodeForm);
            const submitButton = encodeForm.querySelector('button[type="submit"]');
            const originalButtonText = submitButton.innerHTML;
            submitButton.disabled = true;
            submitButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Hiding...';


            fetch('/api/encode', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (response.ok) {
                    return response.blob(); // Expecting a blob (image file)
                } else {
                    return response.json().then(errorData => { // Expecting JSON error
                        throw new Error(errorData.error || 'Encoding failed with status: ' + response.status);
                    });
                }
            })
            .then(imageBlob => {
                const imageUrl = URL.createObjectURL(imageBlob);
                if(encodedImagePreview) {
                    encodedImagePreview.src = imageUrl;
                    encodedImagePreview.style.display = 'block';
                }
                if(downloadLink) {
                    downloadLink.href = imageUrl;
                    // Suggest a filename based on the original, or a default
                    const originalFilename = formData.get('image').name;
                    const base = originalFilename.substring(0, originalFilename.lastIndexOf('.'));
                    const ext = originalFilename.substring(originalFilename.lastIndexOf('.'));
                    downloadLink.download = `${base}_encoded${ext}`;
                }
                if(downloadLinkContainer) downloadLinkContainer.style.display = 'block';
                showAlert('encodeAlerts', 'Message hidden successfully! You can now download the encoded image.', 'success');
            })
            .catch(error => {
                showAlert('encodeAlerts', error.message || 'An unknown error occurred during encoding.', 'danger');
                if(encodedImagePreview) encodedImagePreview.style.display = 'none';
                if(downloadLinkContainer) downloadLinkContainer.style.display = 'none';
            })
            .finally(() => {
                submitButton.disabled = false;
                submitButton.innerHTML = originalButtonText;
            });
        });
    }

    // --- Decode Page Logic ---
    const decodeForm = document.getElementById('decodeForm');
    if (decodeForm) {
        setupImagePreview('imageFile', 'decodeImagePreview'); // Setup preview for image to be decoded

        const revealedMessageTextarea = document.getElementById('revealedMessage');
        const revealedMessageContainer = document.getElementById('revealedMessageContainer');

        decodeForm.addEventListener('submit', function(event) {
            event.preventDefault();
            clearAlerts('decodeAlerts');
            if(revealedMessageContainer) revealedMessageContainer.style.display = 'none';
            if(revealedMessageTextarea) revealedMessageTextarea.value = '';

            const formData = new FormData(decodeForm);
            const submitButton = decodeForm.querySelector('button[type="submit"]');
            const originalButtonText = submitButton.innerHTML;
            submitButton.disabled = true;
            submitButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Revealing...';

            fetch('/api/decode', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json()) // Always expecting JSON (message or error)
            .then(data => {
                if (data.error) {
                    throw new Error(data.error);
                }
                if (data.message) {
                    if(revealedMessageTextarea) revealedMessageTextarea.value = data.message;
                    if(revealedMessageContainer) revealedMessageContainer.style.display = 'block';
                    showAlert('decodeAlerts', 'Message revealed successfully!', 'success');
                } else {
                     throw new Error('Unexpected response from server.');
                }
            })
            .catch(error => {
                showAlert('decodeAlerts', error.message || 'An unknown error occurred during decoding.', 'danger');
                if(revealedMessageContainer) revealedMessageContainer.style.display = 'none';
            })
            .finally(() => {
                submitButton.disabled = false;
                submitButton.innerHTML = originalButtonText;
            });
        });
    }
});
