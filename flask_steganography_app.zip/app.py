from flask import Flask, render_template, request, send_from_directory, jsonify, send_file, after_this_request # Added after_this_request
import os
import cv2
import numpy as np
import base64
from werkzeug.utils import secure_filename
from PIL import Image

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['ALLOWED_EXTENSIONS'] = {'png'}
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# --- Character Dictionaries for XOR Encryption ---
d = {chr(i): i for i in range(256)}
c = {i: chr(i) for i in range(256)}

# --- XOR Encryption & Decryption Functions ---
def xor_encrypt(text, key):
    if not key: raise ValueError("Encryption key cannot be empty.")
    return ''.join([c[d[t] ^ d[key[i % len(key)]]] for i, t in enumerate(text)])

def xor_decrypt(cipher, key):
    if not key: raise ValueError("Decryption key cannot be empty.")
    return ''.join([c[d[ch] ^ d[key[i % len(key)]]] for i, ch in enumerate(cipher)])

# --- Helper Functions ---
def str_to_bits(s_chars):
    return [int(b) for char_val in s_chars for b in format(char_val, '08b')]

def bits_to_bytes(bits):
    return [int(''.join(str(bit) for bit in bits[i:i+8]), 2) for i in range(0, len(bits), 8)]

# --- Image Encoding Function ---
def encode_image_logic(image_path, message, key, output_path):
    try:
        img = cv2.imread(image_path)
        if img is None:
            raise ValueError("Image not found or could not be read. Ensure it's a valid image file.")
        
        flat = img.flatten()
        encrypted = xor_encrypt(message, key)
        b64 = base64.b64encode(encrypted.encode('utf-8')).decode('utf-8')
        bits = str_to_bits([ord(ch) for ch in b64])
        length = len(bits)
        len_bits = list(map(int, format(length, '032b')))
        all_bits = len_bits + bits

        if len(all_bits) > len(flat):
            required_pixels = len(all_bits)
            available_pixels = len(flat)
            raise ValueError(f"Image too small to hold this message! Message requires {required_pixels} bits, image has space for {available_pixels} bits (pixels). Each pixel stores 1 bit.")

        for i, bit in enumerate(all_bits):
            flat[i] = (flat[i] & 0xFE) | bit

        encoded_img = flat.reshape(img.shape)
        cv2.imwrite(output_path, encoded_img)
        return True
    except ValueError as ve:
        raise ve
    except Exception as e:
        print(f"Error during encoding: {e}") # Server-side log
        raise Exception(f"An unexpected error occurred during image encoding: {e}")

# --- Image Decoding Function ---
def decode_image_logic(image_path, key):
    try:
        img = cv2.imread(image_path)
        if img is None:
            raise ValueError("Image not found or could not be read. Ensure it's a valid image file and path is correct.")

        flat = img.flatten()
        if len(flat) < 32:
            raise ValueError("Image is too small to contain any message (cannot read length header).")

        len_bits = [flat[i] & 1 for i in range(32)]
        msg_len = int(''.join(str(b) for b in len_bits), 2)

        if (32 + msg_len) > len(flat):
            raise ValueError("Corrupted or invalid image. Message length encoded in image exceeds image size.")

        data_bits = [flat[i] & 1 for i in range(32, 32 + msg_len)]
        if len(data_bits) % 8 != 0:
             raise ValueError(f"Data corruption: Extracted bit length ({len(data_bits)}) is not a multiple of 8.")

        byte_vals = bits_to_bytes(data_bits)
        b64_str = ''.join(chr(b) for b in byte_vals)
        
        try:
            decoded_bytes = base64.b64decode(b64_str)
            decoded_encrypted = decoded_bytes.decode('utf-8')
        except Exception as e:
            raise ValueError(f"Base64 decoding failed: {e}. The data might be corrupted or not valid Base64.")

        decrypted = xor_decrypt(decoded_encrypted, key)
        return decrypted
    except ValueError as ve:
        raise ve
    except Exception as e:
        print(f"Error during decoding: {e}") # Server-side log
        raise Exception(f"An unexpected error occurred during image decoding: {e}")

def allowed_file(filename):
    return '.' in filename and            filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/encode_page')
def encode_page_route():
    return render_template('encode.html')

@app.route('/decode_page')
def decode_page_route():
    return render_template('decode.html')

@app.route('/api/encode', methods=['POST'])
def api_encode_route():
    if 'image' not in request.files:
        return jsonify({"error": "No image file provided."}), 400
    
    file = request.files['image']
    message = request.form.get('message')
    key = request.form.get('key')

    if not message: return jsonify({"error": "No message provided."}), 400
    if not key: return jsonify({"error": "No key provided."}), 400
    if file.filename == '': return jsonify({"error": "No image selected."}), 400

    original_image_path = None # Initialize to ensure it's always defined for the finally block
    encoded_image_path = None  # Initialize

    if file and allowed_file(file.filename):
        original_filename_secure = secure_filename(file.filename)
        base, ext = os.path.splitext(original_filename_secure)
        
        # Temporary path for the originally uploaded file
        temp_original_filename = f"{base}_{os.urandom(4).hex()}{ext}"
        original_image_path = os.path.join(app.config['UPLOAD_FOLDER'], temp_original_filename)
        
        # Path for the encoded output image
        encoded_image_filename_random_part = os.urandom(4).hex()
        # Keep a clean download name for the user, but unique name on server
        user_download_filename = f"{base}_encoded{ext}" 
        encoded_image_filename_server = f"{base}_encoded_{encoded_image_filename_random_part}{ext}"
        encoded_image_path = os.path.join(app.config['UPLOAD_FOLDER'], encoded_image_filename_server)
        
        response_initiated_by_send_file = False

        try:
            file.save(original_image_path)
            encode_image_logic(original_image_path, message, key, encoded_image_path)
            
            @after_this_request
            def cleanup_encoded_image(response):
                try:
                    if os.path.exists(encoded_image_path):
                        os.remove(encoded_image_path)
                    # app.logger.info(f"Successfully removed encoded file {encoded_image_path}")
                except Exception as e:
                    app.logger.error(f"Error removing encoded file {encoded_image_path}: {e}")
                return response
            
            response_initiated_by_send_file = True
            return send_file(encoded_image_path, as_attachment=True, download_name=user_download_filename)
        
        except ValueError as ve:
            return jsonify({"error": str(ve)}), 400
        except Exception as e:
            app.logger.error(f"Encoding process failed: {e}") # Log the exception server-side
            return jsonify({"error": f"Encoding failed: {str(e)}"}), 500
        finally:
            # Clean up the (potentially temporarily named) original uploaded file
            if original_image_path and os.path.exists(original_image_path):
                os.remove(original_image_path)
            
            # If send_file was not successfully initiated (e.g., an error occurred before it)
            # and the encoded file was created, it needs to be cleaned up here.
            if not response_initiated_by_send_file and encoded_image_path and os.path.exists(encoded_image_path):
                os.remove(encoded_image_path)
                # app.logger.info(f"Cleaned up encoded file {encoded_image_path} due to error before send_file.")

    else:
        return jsonify({"error": "Invalid file type. Only PNG images are allowed."}), 400

@app.route('/api/decode', methods=['POST'])
def api_decode_route():
    if 'image' not in request.files:
        return jsonify({"error": "No image file provided."}), 400
    
    file = request.files['image']
    key = request.form.get('key')

    if not key: return jsonify({"error": "No key provided."}), 400
    if file.filename == '': return jsonify({"error": "No image selected."}), 400

    uploaded_image_path = None # Initialize

    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        base, ext = os.path.splitext(filename)
        # Add randomness to temp filename to avoid collision
        temp_filename = f"{base}_{os.urandom(4).hex()}{ext}"
        uploaded_image_path = os.path.join(app.config['UPLOAD_FOLDER'], temp_filename)
        
        try:
            file.save(uploaded_image_path)
            decoded_message = decode_image_logic(uploaded_image_path, key)
            return jsonify({"message": decoded_message})
            
        except ValueError as ve:
            return jsonify({"error": str(ve)}), 400
        except Exception as e:
            app.logger.error(f"Decoding process failed: {e}") # Log the exception server-side
            return jsonify({"error": f"Decoding failed: {str(e)}"}), 500
        finally:
            if uploaded_image_path and os.path.exists(uploaded_image_path):
                os.remove(uploaded_image_path)
    else:
        return jsonify({"error": "Invalid file type. Only PNG images are allowed."}), 400

if __name__ == '__main__':
    app.run(debug=True, port=5000)
